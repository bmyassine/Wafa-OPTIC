<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="images/favicon.ico" type="image/ico" />

    <title>404 dev | </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
	
    <!-- bootstrap-progressbar -->
    <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="../vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    
    
  </head>


<body>

    <!-- Wrapper -->
    <div id="wrapper" class="wrapper">
        <div class="body_overlay"></div>
        <!-- My Account Page -->
        <div class="my-account-area section-ptb-xl">
            <div class="container">
                <div class="row">
                <div id="login-page">
    <div class="container" style="margin-top:150px; margin-left:270px;">
    <form id="form1" name="form1" method="POST" action="connexion.php">
        <h2 class="form-login-heading"><center>LOGIN</center></h2>
        <div class="login-wrap">
          <input type="text" class="form-control" name="login" placeholder="User ID" autofocus>
          <br>
          <input type="password" class="form-control" name="pwd" placeholder="Password">
          <br>
          <button class="btn btn-dark btn-block" href="index.html" type="submit"><i class="fa fa-lock"></i> SIGN IN</button>
          <hr>
        </div>
      </form>
    </div>
                </div>
            </div>
        </div>
        <!--// My Account Page -->
        <!-- End Footer Area -->
    </div>
    <!--// Wrapper -->


    <!-- Js Files -->
    <script src="js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="js/vendor/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
</body>


<!-- Mirrored from demo.devitems.com/chasmish-v1-tf/chasmish/login-register.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 10 Apr 2020 18:32:16 GMT -->
</html>