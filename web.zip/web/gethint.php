<?PHP
include "../../core/promotionC.php";
include "../../entities/promotion.php";
$codeProd = $_REQUEST["codeprod"];
$promotionC = new promotionC();
$result = $promotionC->recupererproduit($codeProd);
 
foreach( $result as $row){
    $hint=$row["prix"];

}
echo $hint === "" ? "no suggestion" : $hint;

?>