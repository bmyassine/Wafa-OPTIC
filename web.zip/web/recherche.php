
<?php
include "../../core/couponC.php";
$coupon1C = new couponC();
$listecoupons=$coupon1C->recherche($_GET['recherche'],$_GET['champs'],$_GET['tri']);
?>
<?php require_once('header.php'); ?>
<div class="right_col" role="main">
<HTML>
<head>
<meta charset="utf-8" />
</head>
<body>
  

<table border="1">
<tr>
<td>ID coupon</td>
<td>ID client</td>
<td>Code</td>
<td>Date_fin</td>
<td>Pourcentage</td>
<td>utiliser</td>
<td>supprimer</td>

</tr>

<?PHP
foreach($listecoupons as $row){
	?>
	<tr>
	<td><?PHP echo $row['idcoupon']; ?></td>
	<td><?PHP echo $row['idc']; ?></td>
	<td><?PHP echo $row['code']; ?></td>
	<td><?PHP echo $row['date_fin']; ?></td>
    <td><?PHP echo $row['pourcentage']; ?></td>
	<td><?PHP
	
	if ($row['utiliser']==1){ ?> <?PHP 
		$x1="coupon utilise";
	$color1="#4BBB37";
  
	echo "<div style='background-color:$color1'> $x1</div> "?><?php }else{?> <a href="modifiercoupon.php?idcoupon=<?php echo $row['idcoupon']; ?>"> <?PHP 
		$color2="red";
        $x2="coupon non-utilise";  
	echo "<div style='background-color:$color2'>$x2</div>" ?></a><?php } ?></td>
	
	<td><form method="POST" action="supprimercoupon.php">
	<input type="submit" name="supprimer" value="supprimer">
	<input type="hidden" value="<?PHP echo $row['idcoupon']; ?>" name="idcoupon">
	</form>
	</td>
	<td>
    </body>

</HTML>
</td>

	</tr>
	<?PHP
}
?>
 </HTMl>
</div>
<?php require_once('footer.php'); ?>
</table>
